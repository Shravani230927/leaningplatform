import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function CertificatePage() {
  const [certificate, setCertificate] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get(`http://localhost:5000/certificates?courseId=${id}`)
      .then((response) => setCertificate(response.data[0] || null))
      .catch(() => setError('Unable to load certificate.'))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="message">Loading certificate...</div>;
  if (error) return <div className="message error">{error}</div>;
  if (!certificate) return <div className="message">No certificate found.</div>;

  return (
    <section className="page certificate-page">
      <div className="certificate-card">
        <h1>Certificate of Completion</h1>
        <p>This certifies that</p>
        <h2>{certificate.learnerName}</h2>
        <p>has successfully completed the course</p>
        <h3>{certificate.courseTitle}</h3>
        <p>on {certificate.date}</p>
      </div>
      <button className="button" onClick={() => navigate('/')}>Back to courses</button>
    </section>
  );
}
