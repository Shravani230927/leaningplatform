import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000',
  headers: { 'Content-Type': 'application/json' },
});

export async function getCourses() {
  const response = await api.get('/courses');
  return response.data;
}

export async function getCourse(id) {
  const response = await api.get(`/courses/${id}`);
  return response.data;
}

export async function createCourse(course) {
  const response = await api.post('/courses', course);
  return response.data;
}

export async function updateCourse(id, course) {
  const response = await api.put(`/courses/${id}`, course);
  return response.data;
}

export async function deleteCourse(id) {
  const response = await api.delete(`/courses/${id}`);
  return response.data;
}

export async function createCertificate(certificate) {
  const response = await api.post('/certificates', certificate);
  return response.data;
}
