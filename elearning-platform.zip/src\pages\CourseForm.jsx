import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createCourse, getCourse, updateCourse } from '../services/api';

const emptyCourse = {
  title: '',
  description: '',
  duration: '',
  category: '',
  instructor: '',
  videoUrl: '',
  progress: 0,
};

export default function CourseForm() {
  const [course, setCourse] = useState(emptyCourse);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = Boolean(id);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    getCourse(id)
      .then((data) => setCourse(data))
      .catch(() => setError('Unable to load course.'))
      .finally(() => setLoading(false));
  }, [id]);

  function handleChange(event) {
    const { name, value } = event.target;
    setCourse((prev) => ({ ...prev, [name]: value }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (isEdit) {
        await updateCourse(id, { ...course, progress: Number(course.progress) });
      } else {
        await createCourse({ ...course, progress: Number(course.progress) });
      }
      navigate('/');
    } catch {
      setError('Unable to save course.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="page course-form">
      <h1>{isEdit ? 'Edit Course' : 'Create Course'}</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Title
          <input name="title" value={course.title} onChange={handleChange} required />
        </label>
        <label>
          Description
          <textarea name="description" value={course.description} onChange={handleChange} required />
        </label>
        <label>
          Category
          <input name="category" value={course.category} onChange={handleChange} required />
        </label>
        <label>
          Duration
          <input name="duration" value={course.duration} onChange={handleChange} required />
        </label>
        <label>
          Instructor
          <input name="instructor" value={course.instructor} onChange={handleChange} required />
        </label>
        <label>
          Video URL
          <input name="videoUrl" value={course.videoUrl} onChange={handleChange} required />
        </label>
        <label>
          Progress
          <input
            type="number"
            name="progress"
            min="0"
            max="100"
            value={course.progress}
            onChange={handleChange}
          />
        </label>

        {error && <div className="message error">{error}</div>}

        <button type="submit" className="button" disabled={loading}>
          {loading ? 'Saving...' : 'Save Course'}
        </button>
      </form>
    </section>
  );
}
