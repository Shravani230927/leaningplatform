import { NavLink } from 'react-router-dom';

export default function Header() {
  return (
    <header className="header">
      <div className="brand">E-Learning Hub</div>
      <nav>
        <NavLink to="/" end>
          Courses
        </NavLink>
        <NavLink to="/courses/new">Create Course</NavLink>
      </nav>
    </header>
  );
}
