import { Routes, Route, Navigate } from 'react-router-dom';
import CourseList from './pages/CourseList';
import CourseForm from './pages/CourseForm';
import CourseDetails from './pages/CourseDetails';
import CertificatePage from './pages/CertificatePage';
import Header from './components/Header';

export default function App() {
  return (
    <div className="app-shell">
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<CourseList />} />
          <Route path="/courses/new" element={<CourseForm />} />
          <Route path="/courses/edit/:id" element={<CourseForm />} />
          <Route path="/courses/:id" element={<CourseDetails />} />
          <Route path="/certificate/:id" element={<CertificatePage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}
