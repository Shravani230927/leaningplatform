import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getCourses, deleteCourse } from '../services/api';

export default function CourseList() {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  async function loadCourses() {
    setLoading(true);
    setError('');
    try {
      const data = await getCourses();
      setCourses(data);
    } catch (err) {
      setError('Unable to load courses.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadCourses();
  }, []);

  async function handleDelete(id) {
    if (!window.confirm('Delete this course?')) return;
    await deleteCourse(id);
    loadCourses();
  }

  return (
    <section className="page course-list">
      <div className="page-header">
        <h1>Courses</h1>
        <Link className="button" to="/courses/new">
          Add Course
        </Link>
      </div>

      {loading ? (
        <div className="message">Loading courses...</div>
      ) : error ? (
        <div className="message error">{error}</div>
      ) : courses.length === 0 ? (
        <div className="message">No courses found.</div>
      ) : (
        <div className="grid">
          {courses.map((course) => (
            <article key={course.id} className="card">
              <div className="card-body">
                <h2>{course.title}</h2>
                <p>{course.description}</p>
                <p className="meta">
                  {course.category} • {course.duration}
                </p>
                <div className="actions">
                  <Link className="button small" to={`/courses/${course.id}`}>
                    View
                  </Link>
                  <Link className="button small" to={`/courses/edit/${course.id}`}>
                    Edit
                  </Link>
                  <button className="button small danger" onClick={() => handleDelete(course.id)}>
                    Delete
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
