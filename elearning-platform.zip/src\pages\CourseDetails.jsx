import { useEffect, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { getCourse, updateCourse, createCertificate } from '../services/api';

export default function CourseDetails() {
  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);
  const [certificateCreated, setCertificateCreated] = useState(false);
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    if (!id) return;
    getCourse(id)
      .then((data) => {
        setCourse(data);
        setProgress(data.progress);
      })
      .catch(() => setError('Unable to load course.'))
      .finally(() => setLoading(false));
  }, [id]);

  async function handleSaveProgress() {
    if (!course) return;
    setLoading(true);
    try {
      const updated = await updateCourse(course.id, { ...course, progress });
      setCourse(updated);
      if (updated.progress >= 100) {
        await createCertificate({
          courseId: updated.id,
          learnerName: 'John Doe',
          courseTitle: updated.title,
          date: new Date().toLocaleDateString(),
        });
        setCertificateCreated(true);
      }
    } catch {
      setError('Unable to save progress.');
    } finally {
      setLoading(false);
    }
  }

  if (loading) return <div className="message">Loading course...</div>;
  if (error) return <div className="message error">{error}</div>;
  if (!course) return <div className="message">Course not found.</div>;

  return (
    <section className="page course-details">
      <div className="page-header">
        <div>
          <h1>{course.title}</h1>
          <p>{course.description}</p>
        </div>
        <button className="button" onClick={() => navigate('/')}>Back</button>
      </div>

      <div className="video-card">
        <video controls src={course.videoUrl} className="video-player" />
      </div>

      <div className="details-grid">
        <div>
          <p><strong>Instructor:</strong> {course.instructor}</p>
          <p><strong>Category:</strong> {course.category}</p>
          <p><strong>Duration:</strong> {course.duration}</p>
        </div>
        <div>
          <p><strong>Progress:</strong> {course.progress}%</p>
          <progress value={course.progress} max="100"></progress>
        </div>
      </div>

      <div className="progress-control">
        <label>
          Update progress
          <input
            type="range"
            min="0"
            max="100"
            value={progress}
            onChange={(event) => setProgress(Number(event.target.value))}
          />
        </label>
        <button className="button" onClick={handleSaveProgress} disabled={loading}>
          {loading ? 'Saving...' : 'Save Progress'}
        </button>
      </div>

      {certificateCreated && (
        <div className="certificate-callout">
          <p>Certificate generated!</p>
          <Link className="button" to={`/certificate/${course.id}`}>
            View Certificate
          </Link>
        </div>
      )}
    </section>
  );
}
